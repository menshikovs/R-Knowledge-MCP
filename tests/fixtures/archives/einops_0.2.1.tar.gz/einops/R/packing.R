pack <- function(tensors, pattern) {
    
}
