lst<-function(n=500, token){
  headers = c(`Authorization` = paste0("Token ",token))

  res<-content(GET(url = paste0("https://apiv2.nobitex.ir/market/trades/list?pageSize=",n), 
                   add_headers(.headers=headers), 
                    encode = "multipart"))
  list<-do.call(rbind.data.frame, res$trades)
  list
}
