walletLST <- function(token){

  headers = c(`Authorization` = paste0("Token ",token))
  res <- httr::GET(url = "https://apiv2.nobitex.ir/v2/wallets", httr::add_headers(.headers=headers))
  res<-content(res, as = "parsed")

  wallet0<-res$wallet
  wallet0<-do.call(rbind.data.frame, wallet0)
wallet0
}
