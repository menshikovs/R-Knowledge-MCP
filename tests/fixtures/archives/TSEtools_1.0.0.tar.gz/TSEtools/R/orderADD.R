orderADD <- function(typ, src, dst, amnt, prc, stp=NULL, stpL=NULL, exe="limit", token){
  headers = c(`Authorization` = paste0("Token ",token))
  
  if(exe=="limit" | exe=="market"){
    files = list(`type` = typ,`srcCurrency` = src,  `dstCurrency` = dst,
                 `amount` =as.character(amnt),`price` = as.character(prc),`execution`=exe)
    
  }else if(exe=="oco"){
    files = list(`type` = typ,`srcCurrency` = src,  `dstCurrency` = dst,
                 `amount` =as.character(amnt),`price` = as.character(prc),
                 `mode`=exe,`stopPrice`=as.character(stp), `stopLimitPrice`=as.character(stpL))
  }else if(exe=="stop_market" | exe=="stop_limit"){
    files = list(`type` = typ,`srcCurrency` = src,  `dstCurrency` = dst,
                 `amount` = as.character(amnt),`price` = as.character(prc),
                 `execution`=exe,`stopPrice`=as.character(stp))
  }
  
  res<-content(POST(url = "https://apiv2.nobitex.ir/market/orders/add", 
                    httr::add_headers(.headers=headers), 
                    body = files, encode = "multipart"))
  res<-list(res$status, res$message)
  res
  }
