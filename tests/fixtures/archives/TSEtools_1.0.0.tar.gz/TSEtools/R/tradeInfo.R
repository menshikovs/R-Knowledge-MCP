tradeInfo <- function(src){
  sc <-  paste0('https://apiv2.nobitex.ir/v2/trades/',src)
  res <- fromJSON(paste(readLines(sc,warn=FALSE), collapse=""))
  
  res0<-as.data.frame(do.call(rbind,res$trades))
  res0
}
