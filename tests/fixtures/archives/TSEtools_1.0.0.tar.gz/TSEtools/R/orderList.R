orderList<-function(token){
  
  headers = c(
    Authorization = paste0("Token ",token)
  )
  
  res<-GET('https://apiv2.nobitex.ir/market/orders/list?details=2',
      add_headers(.headers=headers)
      )
  
  res<-content(res, as = "parsed")
  
  res<-as.data.frame(do.call(rbind, res$orders))
  
  res$dstCurrency[substr(res$market, 5, 8)=="-RLS"]<-"RLS"
  
  res
  }