cancel<-function(src, dst, hrs = 0, token){
  headers = c(`Authorization` = paste0("Token ",token))
  files = list(`srcCurrency` = src, `dstCurrency` = dst,  `hours`= hrs)
 POST(url = "https://apiv2.nobitex.ir/market/orders/cancel-old",
            add_headers(.headers=headers), body = files, encode = "multipart")
}
