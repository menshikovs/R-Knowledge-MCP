updateStatus<-function(order, st="canceled", token){
  headers = c(`Authorization` = paste0("Token ",token))
  files = list(`order` = as.character(order), `status` = st)
  res <- POST(url = "https://apiv2.nobitex.ir/market/orders/update-status",
                    add_headers(.headers=headers), body = files)
  res
}