lastPrft <- function(period="weekly", token){
  
  prd0 <- ifelse(period=="weekly",FALSE,TRUE)
  
  headers = c(
    Authorization = paste0("Token ",token)
  )
  files = list(`monthly` = prd0)
  res <- httr::POST(url = paste0("https://apiv2.nobitex.ir/users/portfolio/last-week-daily-profit")
                    , httr::add_headers(.headers=headers),body=files)
  res<-content(res, as = "parsed")
  res<-do.call(rbind.data.frame, res$data)
  res
}