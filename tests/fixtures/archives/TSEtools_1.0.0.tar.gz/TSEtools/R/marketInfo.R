marketInfo <- function(src,dst){
params = list(
    srcCurrency = src,
    dstCurrency = dst
  )
  
  res0 <- httr::GET(url = "https://apiv2.nobitex.ir/market/stats", query = params)
  
  res0<-content(res0, as = "parsed")
  
  res0<-data.frame(do.call(cbind,res0$stats))
  return(res0)
}

